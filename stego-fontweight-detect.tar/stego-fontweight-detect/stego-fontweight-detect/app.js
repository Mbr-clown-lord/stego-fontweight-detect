
const style = document.createElement('style');
style.innerHTML = `
  .Yml0ezB9 { font-weight: 500; }
  .Yml0ezF9 { font-weight: 400; }
  .Yml0e259 { font-weight: 450; }
  body {
    font-family: Arial, sans-serif;
    padding: 20px;
    line-height: 1.6;
  }
`;
document.head.appendChild(style);

const textMap = [
  ['Yml0ezB9(', 'We'],
  ['Yml0ezF9(', 'understand'],
  ['Yml0e259(', 'deeply'],
  ['Yml0ezB9(', 'the'],
  ['Yml0ezF9(', 'critical'],
  ['Yml0ezF9(', 'need'],
  ['Yml0ezB9(', 'for'],
  ['Yml0e259(', 'ensuring'],
  ['Yml0ezF9(', 'robust'],
  ['Yml0ezB9(', 'network'],
  ['Yml0ezB9(', 'security'],
  ['Yml0ezF9(', 'in'],
  ['Yml0ezF9(', 'today’s'],
  ['Yml0ezB9(', 'fast-paced'],
  ['Yml0ezF9(', 'digital'],
  ['Yml0ezF9(', 'landscape.'],
  ['Yml0ezB9(', 'With'],
  ['Yml0ezF9(', 'cyber'],
  ['Yml0ezB9(', 'threats'],
  ['Yml0ezF9(', 'evolving'],
  ['Yml0ezF9(', 'rapidly'],
  ['Yml0e259(', 'each'],
  ['Yml0ezF9(', 'it’s'],
  ['Yml0ezF9(', 'essential'],
  ['Yml0ezB9(', 'to'],
  ['Yml0ezB9(', 'have'],
  ['Yml0ezB9(', 'a'],
  ['Yml0e259(', 'strong'],
  ['Yml0ezB9(', 'comprehensive'],
  ['Yml0ezF9(', 'security'],
  ['Yml0ezF9(', 'strategy'],
  ['Yml0ezB9(', 'in'],
  ['Yml0ezF9(', 'place.'],
  ['Yml0ezB9(', 'Our'],
  ['Yml0e259(', 'innovative'],
  ['Yml0ezB9(', 'solutions'],
  ['Yml0ezB9(', 'include'],
  ['Yml0ezB9(', 'real-time'],
  ['Yml0ezF9(', 'attack'],
  ['Yml0ezB9(', 'detection'],
  ['Yml0e259(', 'mechanisms'],
  ['Yml0ezF9(', 'and'],
  ['Yml0ezF9(', 'continuous'],
  ['Yml0ezB9(', 'monitoring'],
  ['Yml0ezF9(', 'to'],
  ['Yml0ezB9(', 'safeguard'],
  ['Yml0ezB9(', 'your'],
  ['Yml0ezB9(', 'networks'],
  ['Yml0ezF9(', 'ensuring'],
  ['Yml0ezF9(', 'any'],
  ['Yml0e259(', 'emerging'],
  ['Yml0ezB9(', 'potential'],
  ['Yml0ezB9(', 'threats'],
  ['Yml0ezF9(', 'are'],
  ['Yml0ezF9(', 'identified'],
  ['Yml0ezB9(', 'and'],
  ['Yml0ezF9(', 'neutralized'],
  ['Yml0ezF9(', 'before'],
  ['Yml0ezF9(', 'they'],
  ['Yml0e259(', 'can'],
  ['Yml0ezB9(', 'cause'],
  ['Yml0ezF9(', 'harm'],
  ['Yml0ezB9(', 'Beyond'],
  ['Yml0ezB9(', 'proactive'],
  ['Yml0ezB9(', 'threat'],
  ['Yml0ezB9(', 'management'],
  ['Yml0ezF9(', 'we'],
  ['Yml0ezF9(', 'also'],
  ['Yml0ezB9(', 'offer'],
  ['Yml0ezB9(', 'data'],
  ['Yml0ezF9(', 'protection'],
  ['Yml0e259(', 'and'],
  ['Yml0ezF9(', 'services'],
  ['Yml0ezB9(', 'including'],
  ['Yml0ezF9(', 'encryption'],
  ['Yml0ezF9(', 'secure'],
  ['Yml0ezB9(', 'storage'],
  ['Yml0ezB9(', 'and'],
  ['Yml0ezB9(', 'backup'],
  ['Yml0ezB9(', 'strategies'],
  ['Yml0ezF9(', 'to'],
  ['Yml0ezB9(', 'prevent'],
  ['Yml0ezF9(', 'unauthorized'],
  ['Yml0ezB9(', 'access'],
  ['Yml0ezF9(', 'and'],
  ['Yml0e259(', 'to'],
  ['Yml0ezB9(', 'ensure'],
  ['Yml0ezF9(', 'data'],
  ['Yml0ezF9(', 'integrity'],
  ['Yml0ezF9(', 'In'],
  ['Yml0ezB9(', 'addition'],
  ['Yml0ezB9(', 'to'],
  ['Yml0ezF9(', 'our'],
  ['Yml0ezF9(', 'technical'],
  ['Yml0ezB9(', 'solutions'],
  ['Yml0ezF9(', 'we'],
  ['Yml0e259(', 'consistently'],
  ['Yml0ezB9(', 'provide'],
  ['Yml0ezF9(', 'expert'],
  ['Yml0ezB9(', 'consulting'],
  ['Yml0ezB9(', 'to'],
  ['Yml0ezF9(', 'help'],
  ['Yml0ezF9(', 'organizations'],
  ['Yml0ezF9(', 'assess'],
  ['Yml0ezB9(', 'their'],
  ['Yml0e259(', 'existing'],
  ['Yml0ezB9(', 'current'],
  ['Yml0ezF9(', 'security'],
];
function displayText() {
    const contentElement = document.getElementById('content');
    let text = '';

    textMap.forEach(item => {
        const className = item[0].replace('(', ''); 
        const word = item[1];
        text += `<span class="${className}">${word}</span> `;
    });

    contentElement.innerHTML = text;
}


window.onload = displayText;

